package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Deal;
import com.deal.buddy.web.bean.UserDevice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserDeviceRepository extends JpaRepository<UserDevice, String> {

}
