package com.deal.buddy.web.config;

import org.hibernate.dialect.PostgreSQLDialect;

public class JsonPGSqlDialect extends PostgreSQLDialect {
    public JsonPGSqlDialect() {
        super();
//        this.registerColumnType(Types.JAVA_OBJECT, "json");
    }
}
