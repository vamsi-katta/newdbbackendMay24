package com.deal.buddy.web.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Coupon;
import com.deal.buddy.web.bean.CouponComparator;
import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.bean.UserSavedCoupon;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.NotFoundException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.CouponRepository;
import com.deal.buddy.web.repository.SubscriptionsRepository;
import com.deal.buddy.web.repository.UserRepository;
import com.deal.buddy.web.repository.UserSavedCouponRepository;

import io.swagger.v3.oas.annotations.Operation;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/coupons")
public class CouponController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(CouponController.class);
    private CouponComparator couponComparator = new CouponComparator();

    @Autowired
    CouponRepository couponRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserSavedCouponRepository userSavedCouponRepository;

    @Autowired
    SubscriptionsRepository subscriptionsRepository;

    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    Coupon addCoupon(@RequestBody Coupon coupon, @RequestHeader String userEmail)
            throws Exception {
        isPreviliged(userEmail);
        if (0 == coupon.getEntryTime()) {
            coupon.setEntryTime(System.currentTimeMillis());
        }
        coupon.setImageUrl(getS3ImageUrl(coupon.getType(), coupon.getBase64ImageBytes()));
        coupon.setBase64ImageBytes(null);
        logger.info("Coupon added : {}", coupon);
        couponRepository.save(coupon);
        return coupon;
    }

    @RequestMapping(value = "/likeCoupon", method = {RequestMethod.POST})
    public @ResponseBody
    Coupon likeCoupon(@RequestParam String couponId, @RequestParam String userEmail)
            throws Exception {
        if (StringUtils.isBlank(couponId)) {
            throw new BadRequestException("Coupon Id is not specified..");
        }
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        Optional<Coupon> couponOptional = couponRepository.findById(couponId);
        if (null == user) {
            throw new BadRequestException("Coupon not found with id " + couponId);
        }
        Coupon coupon = couponOptional.get();
        Subscription likedSubscription = new Subscription();
        likedSubscription.setUserId(user.getId());
        likedSubscription.setKeywords(coupon.getKeywords());
        logger.info("Subscription added with : {}", coupon.getKeywords().toString());
        subscriptionsRepository.save(likedSubscription);
        return coupon;
    }

    @RequestMapping(value = "/matchedCoupons", method = {RequestMethod.GET})
    public @ResponseBody
    List<Coupon> matchedCoupons(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        Set<Subscription> subScriptionSet = getAllPreferences(userEmail);
        List<Coupon> matchedCouponss = new ArrayList<Coupon>();
        if (null == subScriptionSet) {
            return matchedCouponss;
        }
        for (Subscription subScription : subScriptionSet) {
            matchedCouponss.addAll(couponRepository.findBySearchTerms(subScription.getKeywords()));
        }
        Collections.sort(matchedCouponss, couponComparator);
        return matchedCouponss;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    List<Coupon> getAllCoupons() {
        List<String> coupons = null;
        List<Coupon> allCoupons = couponRepository.findAll();
        Collections.sort(allCoupons, couponComparator);
        return allCoupons;
    }

    @RequestMapping(method = {RequestMethod.DELETE})
    public ResponseEntity<String> deleteCoupon(@RequestParam String couponId, @RequestHeader String dealerRoleUserEmail)
            throws Exception {
        isPreviliged(dealerRoleUserEmail);
        Coupon coupon = couponRepository.findById(couponId).orElse(null);
        if (null == coupon) {
            throw new NotFoundException("Coupon with " + couponId + " is not found!!");
        }
        String imageUrl = coupon.getImageUrl();
        String s3FileName = getS3FileName(imageUrl);
        if (StringUtils.isNotBlank(s3FileName)) {
            s3Utils.deleteKey(s3FileName);
        }
        couponRepository.deleteById(couponId);
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/localCoupons", method = {RequestMethod.GET})
    @ResponseBody
    public List<Coupon> localCoupons(@RequestParam String latitude, @RequestParam String longitude) throws Exception {

        double lat = NumberUtils.toDouble(latitude);
        double longi = NumberUtils.toDouble(longitude);
        String zipCode = getZipCode(lat, longi);
        return getCouponsByZipCode(zipCode);
    }

    private List<Coupon> getCouponsByZipCode(String zipCode) {
        List<Coupon> localCoupons = new ArrayList<Coupon>();
        if (StringUtils.isBlank(zipCode)) {
            return localCoupons;
        }
        localCoupons = couponRepository.findByZipCode(zipCode);
        Collections.sort(localCoupons, couponComparator);
        return localCoupons;
    }

    @RequestMapping(value = "/couponsByZipcode", method = {RequestMethod.GET})
    @ResponseBody
    public List<Coupon> couponsByZipcode(@RequestParam String zipCode) throws Exception {

        return getCouponsByZipCode(zipCode);
    }

    @RequestMapping(value = "/bookmarkCoupon", method = {RequestMethod.POST})
    @ResponseBody
    public UserSavedCoupon bookmarkCoupon(@RequestParam String userEmail, @RequestParam String couponId)
            throws Exception {
        if (StringUtils.isBlank(couponId)) {
            throw new BadRequestException("Coupon Id is not specified..");
        }
        Coupon coupon = couponRepository.findById(couponId).orElse(null);
        if (null == coupon) {
            throw new NotFoundException("Coupon with " + couponId + " is not found!!");
        }
        UserSavedCoupon userSavedCoupon = new UserSavedCoupon();
        User user = userRepository.findByUserEmail(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        userSavedCoupon.setCouponId(coupon.getId());
        userSavedCoupon.setUserId(user.getId());
        userSavedCouponRepository.save(userSavedCoupon);
        return userSavedCoupon;
    }

    @RequestMapping(value = "/deleteCouponFromBookmark", method = {RequestMethod.DELETE})
    @ResponseBody
    public ResponseEntity<String> deleteFromCouponBookmark(@RequestParam String userEmail,
                                                           @RequestParam String couponId) throws Exception {
        if (StringUtils.isBlank(couponId)) {
            throw new BadRequestException("Coupon Id is not specified..");
        }
        User user = userRepository.findByUserEmail(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        UserSavedCoupon userSavedCoupon = userSavedCouponRepository.findByUserIdAndCouponId(user.getId(), couponId);
        if (null == userSavedCoupon) {
            throw new NotFoundException("Bookmark not found with " + couponId);
        }
        userSavedCouponRepository.deleteById(userSavedCoupon.getId());
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/savedCoupons", method = {RequestMethod.GET})
    public @ResponseBody
    List<Coupon> savedCoupons(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        List<Coupon> savedCoupons = userSavedCouponRepository.findByUserId(user.getId());
        Collections.sort(savedCoupons, couponComparator);
        return savedCoupons;
    }
    
    @Operation(summary = "Get list of online only coupons.")
    @RequestMapping(value = "/onlineOnlyCoupons", method = {RequestMethod.GET})
    @ResponseBody
    public List<Coupon> onlineOnlyCoupons() {
    	List<Coupon> coupons = Optional.ofNullable(couponRepository.findByOnlineOnlyIgnoreCase("Yes"))
    			.orElse(new ArrayList<>());
    	return coupons;
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({NotFoundException.class})
    ResponseEntity<String> handleNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
