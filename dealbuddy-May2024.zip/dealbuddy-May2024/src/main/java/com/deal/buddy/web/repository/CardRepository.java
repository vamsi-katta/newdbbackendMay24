package com.deal.buddy.web.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.deal.buddy.web.bean.Card;

public interface CardRepository extends JpaRepository<Card, String> {

}
