package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "db_events")
public class Event {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    String id;
    long entryTime;
    long startDate;
    long endDate;
    String timeWindow;
    String title;
    String cost;
    String orgnizerName;
    String orgnizerDetailsUrl;
    String city;
    String zipCode;
    String imageUrl;
    String base64ImageBytes;
    String type = "event";

    @Override
    public String toString() {
        return "Event [id=" + id + ", entryTime=" + entryTime + ", startDate=" + startDate + ", endDate=" + endDate
                + ", timeWindow=" + timeWindow + ", title=" + title + ", cost=" + cost + ", orgnizerName="
                + orgnizerName + ", orgnizerDetailsUrl=" + orgnizerDetailsUrl + ", city=" + city + ", zipCode="
                + zipCode + ", imageUrl=" + imageUrl + ", base64ImageBytes=" + base64ImageBytes + ", type=" + type
                + "]";
    }

}