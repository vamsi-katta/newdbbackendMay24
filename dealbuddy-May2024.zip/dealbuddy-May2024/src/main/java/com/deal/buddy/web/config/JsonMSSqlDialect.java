package com.deal.buddy.web.config;

import org.hibernate.dialect.SQLServerDialect;

import java.sql.Types;

public class JsonMSSqlDialect extends SQLServerDialect {
    public JsonMSSqlDialect() {
        super();
//        this.registerColumnType(Types.JAVA_OBJECT, "json");
//        this.registerColumnType(Types.ARRAY, "array");
    }
}
