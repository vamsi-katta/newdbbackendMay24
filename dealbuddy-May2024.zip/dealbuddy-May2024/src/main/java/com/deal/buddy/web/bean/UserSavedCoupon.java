package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.io.Serializable;

@Entity
@Getter
@Setter
@Table(name = "db_user_saved_coupons")
public class UserSavedCoupon implements Serializable {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    String id;
    String userId;
    String couponId;


    @Override
    public String toString() {
        return "UserSavedCoupons [id=" + id + ", userId=" + userId + ", couponId=" + couponId + "]";
    }

}