package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "db_subscriptions")
public class Subscription {
	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	String id;
	String userId;
	String[] categories;
	String[] keywords;
	String[] brands;
	String[] vendors;

	@Override
	public String toString() {
		return "Subscription [id=" + id + ", userId=" + userId + ", categories=" + categories + ", keywords=" + keywords
				+ ", brands=" + brands + ", vendors=" + vendors + "]";
	}

}