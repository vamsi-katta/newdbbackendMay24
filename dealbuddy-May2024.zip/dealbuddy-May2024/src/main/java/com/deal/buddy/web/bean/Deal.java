package com.deal.buddy.web.bean;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "db_deals")
public class Deal {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	String id;
	long entryTime;
	long expDate;
	String title;
	String description;
	String url;
	String imageUrl;
	String[] categories;
	String[] keywords;
	String brand;
	String vendor;
	String base64ImageBytes;
	String zipCode;
	String city;
	String type = "deal";
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String onlineOnly;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String instoreOnly;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String onlineAndInstore;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String locations;

}