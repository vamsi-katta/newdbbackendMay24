package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Getter
@Setter
@Table(name = "db_user_saved_events")
public class UserSavedEvent {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    String id;
    String userId;
    String eventId;


    @Override
    public String toString() {
        return "UserSavedEvent [id=" + id + ", userId=" + userId + ", eventId=" + eventId + "]";
    }


}