package com.deal.buddy.web.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.repository.CouponRepository;
import com.deal.buddy.web.repository.DealRepository;
import com.deal.buddy.web.repository.EventRepository;
import com.deal.buddy.web.repository.SubscriptionsRepository;
import com.deal.buddy.web.repository.UserDeviceRepository;
import com.deal.buddy.web.repository.UserRepository;
import com.deal.buddy.web.repository.UserSavedCouponRepository;
import com.deal.buddy.web.repository.UserSavedDealRepository;
import com.deal.buddy.web.repository.UserSavedEventRepository;
import com.deal.buddy.web.repository.UserVerifyRepository;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/index")
@Lazy
public class IndexController extends BaseController {

    @Autowired
    DealRepository dealRepository;

    @Autowired
    CouponRepository couponRepository;

    @Autowired
    EventRepository eventRepository;

    @Autowired
    UserDeviceRepository userDeviceRepository;

    @Autowired
    SubscriptionsRepository subscriptionsRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserSavedCouponRepository userSavedCouponRepository;

    @Autowired
    UserSavedDealRepository userSavedDealRepository;

    @Autowired
    UserSavedEventRepository userSavedEventRepository;

    @Autowired
    UserVerifyRepository userVerifyRepository;

    @RequestMapping(value = "/deal", method = {RequestMethod.DELETE})
    public void deleteDealIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        dealRepository.deleteAll();
    }

    @RequestMapping(value = "/coupon", method = {RequestMethod.DELETE})
    public void deleteCouponIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        couponRepository.deleteAll();
    }

    @RequestMapping(value = "/event", method = {RequestMethod.DELETE})
    public void deleteEventIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        eventRepository.deleteAll();
    }

    @RequestMapping(value = "/device", method = {RequestMethod.DELETE})
    public void deleteDeviceIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        userDeviceRepository.deleteAll();
    }

    @RequestMapping(value = "/subscription", method = {RequestMethod.DELETE})
    public void deleteSubscriptionIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        subscriptionsRepository.deleteAll();
    }

    @RequestMapping(value = "/user", method = {RequestMethod.DELETE})
    public void deleteUserIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        userRepository.deleteAll();
    }

    @RequestMapping(value = "/savedCoupons", method = {RequestMethod.DELETE})
    public void deleteSavedCouponsIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        userSavedCouponRepository.deleteAll();
    }

    @RequestMapping(value = "/savedDeals", method = {RequestMethod.DELETE})
    public void deleteSavedDealsIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        userSavedDealRepository.deleteAll();
    }

    @RequestMapping(value = "/userVerify", method = {RequestMethod.DELETE})
    public void deleteUsersVerifysIndex(@RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        userVerifyRepository.deleteAll();
    }

}
