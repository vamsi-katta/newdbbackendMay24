package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Deal;
import com.deal.buddy.web.bean.Event;
import com.deal.buddy.web.bean.UserSavedDeal;
import com.deal.buddy.web.bean.UserSavedEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface UserSavedEventRepository extends JpaRepository<UserSavedEvent, String> {

    @Query("select s from UserSavedEvent s where s.userId = :userId and s.eventId = :eventId")
    UserSavedEvent findByUserIdAndEventId(@Param("userId") String userId, @Param("eventId") String eventId);

    @Query("select e from UserSavedEvent s, Event e where s.userId = :userId and e.id=s.eventId")
    List<Event> findByUserId(@Param("userId") String userId);
}
