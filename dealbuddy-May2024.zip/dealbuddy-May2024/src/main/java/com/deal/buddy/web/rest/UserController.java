package com.deal.buddy.web.rest;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.bean.UserVerify;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.UserRepository;
import com.deal.buddy.web.repository.UserVerifyRepository;

import jakarta.mail.internet.MimeMessage;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/users")
@Lazy
public class UserController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(UserController.class);
    @Autowired
    JavaMailSender sender;

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserVerifyRepository userVerifyRepository;

    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    User addUser(@RequestBody User userBean) throws Exception {
        logger.info("User added : {}", userBean);
        User userFetched = checkUser(userBean.getUserEmail());
        if (null == userFetched) {
            userRepository.save(userBean);
        } else {
            userBean.setId(userFetched.getId());
            userRepository.save(userBean);
        }
        return userBean;
    }

    @RequestMapping(value = "/updateEmail", method = {RequestMethod.POST})
    public @ResponseBody
    User updateEmail(@RequestParam String userEmail, @RequestParam String newEmail)
            throws Exception {

        if (StringUtils.isBlank(userEmail)) {
            throw new BadRequestException("userEmail is not specified!!");
        }
        if (StringUtils.isBlank(newEmail)) {
            throw new BadRequestException("newEmail is not specified!!");
        }
        logger.info("Update Email for {} as : {}", userEmail, newEmail);
        User userFetched = checkUser(userEmail);
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        } else {
            userFetched.setUserEmail(newEmail);
            userRepository.save(userFetched);
        }
        return userFetched;
    }

    @RequestMapping(value = "/addRole", method = {RequestMethod.POST})
    public @ResponseBody
    User addRole(@RequestBody User user, @RequestHeader("Authorization") String authorization)
            throws Exception {
        if (StringUtils.isBlank(authorization) || !"dealbreaker".equalsIgnoreCase(authorization)) {
            throw new BadRequestException("User authorization failed!!");
        }
        User userFetched = checkUser(user.getUserEmail());
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + user.getUserEmail() + " is not found!!");
        }
        logger.info("UserRole added : {}", user);
        userFetched.setRole(user.getRole());
        userRepository.save(userFetched);
        return user;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    Set<User> getAllUsers() {
        Set<User> allUsers = new HashSet<User>(userRepository.findAll());
        return allUsers;
    }

    @RequestMapping(value = "/user", method = {RequestMethod.GET})
    public @ResponseBody
    User getUserByEmail(@RequestParam String userEmail) throws Exception {
        User userFetched = checkUser(userEmail);
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        return userFetched;
    }

    @RequestMapping(value = "/verifyCode", method = {RequestMethod.GET})
    @ResponseBody
    public String verifyCode(@RequestParam String userEmail, @RequestParam String code) throws Exception {
        UserVerify userVerifyObj = userVerifyRepository.findByUserEmail(userEmail);
        if (null == userVerifyObj) {
            throw new BadRequestException("User verification failed.. Record not found for " + userEmail);
        }
        if (userVerifyObj.getVerifyCode().equalsIgnoreCase(code)) {
            userVerifyRepository.deleteById(userVerifyObj.getId());
            return "User verification success..";
        }
        throw new BadRequestException("User verification failed.. Verification code not matched..");
    }

    @RequestMapping(value = "/requestCode", method = {RequestMethod.GET})
    @ResponseBody
    public String requestVerifyUser(@RequestParam String userEmail) {
        try {
            MimeMessage message = sender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message);
            helper.setTo(userEmail);
            String randomCode = null;
            UserVerify verify = userVerifyRepository.findByUserEmail(userEmail);;
            if (null == verify) {
                verify = new UserVerify();
                randomCode = RandomStringUtils.randomAlphanumeric(8);
            } else {
                randomCode = verify.getVerifyCode();
            }
            helper.setText(
                    "How are you? \n Please use below code to continue access to your account. \n\n Verification Code : "
                            + randomCode);
            verify.setVerifyCode(randomCode);
            verify.setUserEmail(userEmail);
            helper.setSubject("Deal Buddy Verification code !!");
            sender.send(message);
            userVerifyRepository.save(verify);
            return "Email Sent!";
        } catch (Exception ex) {
            return "Error in sending email: " + ex;
        }
    }

    @RequestMapping(method = {RequestMethod.DELETE})
    public void deleteUser(@RequestParam String userIdToBeDeleted, @RequestHeader String dealRoleUserEmail)
            throws Exception {
        isPreviliged(dealRoleUserEmail);
        userRepository.deleteById(userIdToBeDeleted);
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
