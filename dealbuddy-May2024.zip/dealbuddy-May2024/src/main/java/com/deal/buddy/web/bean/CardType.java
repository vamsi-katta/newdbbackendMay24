package com.deal.buddy.web.bean;

public enum CardType {
	DEBIT, CREDIT;
}
