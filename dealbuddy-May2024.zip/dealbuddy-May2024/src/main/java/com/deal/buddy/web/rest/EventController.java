package com.deal.buddy.web.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Event;
import com.deal.buddy.web.bean.EventComparator;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.bean.UserSavedEvent;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.NotFoundException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.EventRepository;
import com.deal.buddy.web.repository.UserSavedEventRepository;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/events")
@Lazy
public class EventController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(EventController.class);
    private EventComparator eventComparator = new EventComparator();

    @Autowired
    EventRepository eventRepository;

    @Autowired
    UserSavedEventRepository userSavedEventRepository;

    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    Event addEvent(@RequestBody Event event, @RequestHeader String dealerRoleUserEmail)
            throws Exception {
        isPreviliged(dealerRoleUserEmail);
        if (0 == event.getEntryTime()) {
            event.setEntryTime(System.currentTimeMillis());
        }
        event.setImageUrl(getS3ImageUrl(event.getType(), event.getBase64ImageBytes()));
        event.setBase64ImageBytes(null);
        logger.info("Event added : {}", event);
        eventRepository.save(event);
        return event;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    List<Event> getAllEvents() {
        List<Event> allEvents = eventRepository.findAll();
        Collections.sort(allEvents, eventComparator);
        return allEvents;
    }

    @RequestMapping(method = {RequestMethod.DELETE})
    public ResponseEntity<String> deleteEvent(@RequestParam String eventId, @RequestHeader String dealerRoleUserEmail) throws Exception {
        isPreviliged(dealerRoleUserEmail);
        Event event = eventRepository.findById(eventId).orElse(null);
        if (null == event) {
            throw new BadRequestException("Event not found with id " + eventId);
        }
        String imageUrl = event.getImageUrl();
        String s3FileName = getS3FileName(imageUrl);
        if (StringUtils.isNotBlank(s3FileName)) {
            s3Utils.deleteKey(s3FileName);
        }
        eventRepository.deleteById(eventId);
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/localEvents", method = {RequestMethod.GET})
    @ResponseBody
    public List<Event> localEvents(@RequestParam String latitude, @RequestParam String longitude) throws Exception {

        double lat = NumberUtils.toDouble(latitude);
        double longi = NumberUtils.toDouble(longitude);
        String zipCode = getZipCode(lat, longi);
        return getEventsByZipCode(zipCode);
    }

    private List<Event> getEventsByZipCode(String zipCode) {
        List<Event> localEvents = new ArrayList<Event>();
        if (StringUtils.isBlank(zipCode)) {
            return localEvents;
        }
        localEvents = eventRepository.findByZipCode(zipCode);
        Collections.sort(localEvents, eventComparator);
        return localEvents;
    }

    @RequestMapping(value = "/eventsByZipcode", method = {RequestMethod.GET})
    @ResponseBody
    public List<Event> eventsByZipcode(@RequestParam String zipCode) throws Exception {
        return getEventsByZipCode(zipCode);
    }

    @RequestMapping(value = "/bookmarkEvent", method = {RequestMethod.POST})
    @ResponseBody
    public UserSavedEvent bookmarkEvent(@RequestParam String userEmail, @RequestParam String eventId) throws Exception {
        if (StringUtils.isBlank(eventId)) {
            throw new BadRequestException("Event Id is not specified..");
        }
        Event event = eventRepository.findById(eventId).orElse(null);
        if (null == event) {
            throw new NotFoundException("Event with " + eventId + " is not found!!");
        }
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        UserSavedEvent userSavedEvent = new UserSavedEvent();
        userSavedEvent.setEventId(event.getId());
        userSavedEvent.setUserId(user.getId());
        userSavedEventRepository.save(userSavedEvent);
        return userSavedEvent;
    }

    @RequestMapping(value = "/deleteEventFromBookmark", method = {RequestMethod.DELETE})
    @ResponseBody
    public ResponseEntity<String> deleteEventFromBookmark(@RequestParam String userEmail, @RequestParam String eventId)
            throws Exception {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        if (StringUtils.isBlank(eventId)) {
            throw new BadRequestException("Event Id is not specified..");
        }
        UserSavedEvent userSavedEvent = userSavedEventRepository.findByUserIdAndEventId(user.getId(), eventId);
        if (null == userSavedEvent) {
            throw new NotFoundException("Bookmark not found with " + eventId);
        }
        userSavedEventRepository.deleteById(userSavedEvent.getId());
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/savedEvents", method = {RequestMethod.GET})
    public @ResponseBody
    List<Event> savedEvents(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        List<Event> savedEvents = userSavedEventRepository.findByUserId(user.getId());
        Collections.sort(savedEvents, eventComparator);
        return savedEvents;
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({NotFoundException.class})
    ResponseEntity<String> handleNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
