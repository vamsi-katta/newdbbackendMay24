package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.UserVerify;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Set;

public interface UserVerifyRepository extends JpaRepository<UserVerify, String> {

    @Query("select s from UserVerify s where s.userEmail = :userEmail")
    UserVerify findByUserEmail(@Param("userEmail") String userEmail);

}
