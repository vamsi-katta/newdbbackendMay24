package com.deal.buddy.web.bean;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "db_coupons")
public class Coupon {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	@Column(name = "coupon_id")
	String id;
	Long entryTime;
	Long expDate;
	String title;
	@NotNull
	String code;
	String description;
	String url;
	String[] categories;
	@NotNull
	String[] keywords;
	String vendor;
	String notes;
	String imageUrl;
	String base64ImageBytes;
	String zipCode;
	String city;
	String type = "coupon";
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String onlineOnly;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String instoreOnly;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String onlineAndInstore;
	@Column(columnDefinition = "VARCHAR(255) DEFAULT ''", nullable = false)
	String locations;

}