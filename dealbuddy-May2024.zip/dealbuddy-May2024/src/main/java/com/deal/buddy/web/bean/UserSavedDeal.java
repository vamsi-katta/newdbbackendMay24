package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;

@Entity
@Getter
@Setter
@Table(name = "db_user_saved_deals")
public class UserSavedDeal {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    String id;
    String userId;
    String dealId;


    @Override
    public String toString() {
        return "UserSavedDeals [id=" + id + ", userId=" + userId + ", dealId=" + dealId + "]";
    }

}