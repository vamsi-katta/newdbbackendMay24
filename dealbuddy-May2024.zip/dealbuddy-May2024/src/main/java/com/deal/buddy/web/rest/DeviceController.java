package com.deal.buddy.web.rest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.bean.UserDevice;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.UserDeviceRepository;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/devices")
public class DeviceController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(DeviceController.class);

    @Autowired
    UserDeviceRepository userDeviceRepository;

    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    UserDevice addDevice(@RequestBody UserDevice userDeviceBean) throws Exception {
        if (StringUtils.isBlank(userDeviceBean.getDeviceId())) {
            throw new BadRequestException("Device Id is null!!");
        }
        if (StringUtils.isBlank(userDeviceBean.getOs())) {
            throw new BadRequestException("Device OS is null!!");
        }
        User userFetched = checkUser(userDeviceBean.getUserEmail());
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + userDeviceBean.getUserEmail() + " is not found!!");
        }
        logger.info("UserDevice added : {}", userDeviceBean);
        userDeviceRepository.save(userDeviceBean);
        return userDeviceBean;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    Set<UserDevice> getAllDevices() {
        List<UserDevice> userDeviceList = userDeviceRepository.findAll();
        Set<UserDevice> allDevices = new HashSet<UserDevice>();
        if (null != userDeviceList) {
            for (UserDevice device : userDeviceList) {
                allDevices.add(device);
            }
        }
        return allDevices;
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
