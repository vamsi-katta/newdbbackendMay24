package com.deal.buddy.web.bean;

import java.util.Comparator;

public class DealComparator implements Comparator<Deal> {

	public int compare(Deal deal1, Deal deal2) {
		if (deal1.getEntryTime() > deal2.getEntryTime()) {
			return -1;
		} else if (deal1.getEntryTime() < deal2.getEntryTime()) {
			return 1;
		} else {
			return 0;
		}
	}

}
