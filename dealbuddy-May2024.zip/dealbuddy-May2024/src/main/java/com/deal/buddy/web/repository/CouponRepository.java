package com.deal.buddy.web.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.deal.buddy.web.bean.Coupon;

public interface CouponRepository extends JpaRepository<Coupon, String> {

	List<Coupon> findByZipCode(String zipCode);

	@Query("select c from Coupon c where c.vendor IN :searchTerms OR c.keywords IN :searchTerms OR c.categories IN :searchTerms")
	List<Coupon> findBySearchTerms(@Param("searchTerms") String[] searchTerms);

	List<Coupon> findByOnlineOnlyIgnoreCase(String onlineOnly);

}
