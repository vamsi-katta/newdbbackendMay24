package com.deal.buddy.web.bean;

import java.util.Comparator;

public class CouponComparator implements Comparator<Coupon> {

	public int compare(Coupon coupon1, Coupon coupon2) {
		if (coupon1.getEntryTime() > coupon2.getEntryTime()) {
			return -1;
		} else if (coupon1.getEntryTime() < coupon2.getEntryTime()) {
			return 1;
		} else {
			return 0;
		}
	}

}
