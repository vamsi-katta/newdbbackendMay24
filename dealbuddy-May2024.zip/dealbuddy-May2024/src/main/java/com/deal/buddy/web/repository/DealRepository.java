package com.deal.buddy.web.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.deal.buddy.web.bean.Deal;

public interface DealRepository extends JpaRepository<Deal, String> {

    List<Deal> findByZipCode(String zipCode);

    @Query("select d from Deal d where d.vendor IN :searchTerms OR d.brand IN :searchTerms OR d.keywords IN :searchTerms OR d.categories IN :searchTerms")
    List<Deal> findBySearchTerms(@Param("searchTerms") String[] searchTerms);
    
    List<Deal> findByOnlineOnlyIgnoreCase(String onlineOnly);
}
