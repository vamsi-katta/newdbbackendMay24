package com.deal.buddy.web.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Deal;
import com.deal.buddy.web.bean.DealComparator;
import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.bean.UserSavedDeal;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.NotFoundException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.DealRepository;
import com.deal.buddy.web.repository.SubscriptionsRepository;
import com.deal.buddy.web.repository.UserSavedDealRepository;

import io.swagger.v3.oas.annotations.Operation;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/deals")
@Lazy
public class DealController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(DealController.class);
    private DealComparator dealComparator = new DealComparator();

    @Autowired
    DealRepository dealRepository;

    @Autowired
    UserSavedDealRepository userSavedDealRepository;

    @Autowired
    SubscriptionsRepository subscriptionsRepository;

    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    Deal addDeal(@RequestBody Deal deal, @RequestHeader String dealerRoleUserEmail)
            throws Exception {
        isPreviliged(dealerRoleUserEmail);
        if (0 == deal.getEntryTime()) {
            deal.setEntryTime(System.currentTimeMillis());
        }
        deal.setImageUrl(getS3ImageUrl(deal.getType(), deal.getBase64ImageBytes()));
        deal.setBase64ImageBytes(null);
        logger.info("Deal added : {}", deal);
        dealRepository.save(deal);
        return deal;
    }

    @RequestMapping(value = "/likeDeal", method = {RequestMethod.POST})
    public @ResponseBody
    Deal likeDeal(@RequestParam String dealId, @RequestParam String userEmail) throws Exception {
        if (StringUtils.isBlank(dealId)) {
            throw new BadRequestException("Deal Id is not specified..");
        }
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        Deal deal = dealRepository.findById(dealId).orElse(null);
        if (null == deal) {
            throw new BadRequestException("Deal not found with id " + dealId);
        }
        Subscription likedSubscription = new Subscription();
        likedSubscription.setUserId(user.getId());
        likedSubscription.setKeywords(deal.getKeywords());
        logger.info("Subscription added with : {}", deal.getKeywords().toString());
        subscriptionsRepository.save(likedSubscription);
        return deal;
    }

    @RequestMapping(value = "/matchedDeals", method = {RequestMethod.GET})
    public @ResponseBody
    List<Deal> matchedDeals(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        Set<Subscription> subScriptionSet = getAllPreferences(userEmail);
        List<Deal> matchedDeals = new ArrayList<Deal>();
        if (null == subScriptionSet) {
            return matchedDeals;
        }
        for (Subscription subScription : subScriptionSet) {
            matchedDeals.addAll(dealRepository.findBySearchTerms(subScription.getKeywords()));
        }
        Collections.sort(matchedDeals, dealComparator);
        return matchedDeals;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    List<Deal> getAllDeals() {
        List<Deal> allDeals = dealRepository.findAll();
        Collections.sort(allDeals, dealComparator);
        return allDeals;
    }

    @RequestMapping(method = {RequestMethod.DELETE})
    public ResponseEntity<String> deleteDeal(@RequestParam String dealId, @RequestHeader String dealerRoleUserEmail)
            throws Exception {
        isPreviliged(dealerRoleUserEmail);
        Deal deal = dealRepository.findById(dealId).orElse(null);
        if (null == deal) {
            throw new BadRequestException("Deal not found with id " + dealId);
        }
        String imageUrl = deal.getImageUrl();
        String s3FileName = getS3FileName(imageUrl);
        if (StringUtils.isNotBlank(s3FileName)) {
            s3Utils.deleteKey(s3FileName);
        }
        dealRepository.deleteById(dealId);
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/localDeals", method = {RequestMethod.GET})
    @ResponseBody
    public List<Deal> localDeals(@RequestParam String latitude, @RequestParam String longitude) throws Exception {

        double lat = NumberUtils.toDouble(latitude);
        double longi = NumberUtils.toDouble(longitude);
        String zipCode = getZipCode(lat, longi);
        return getDealsByZipCode(zipCode);
    }

    private List<Deal> getDealsByZipCode(String zipCode) {
        List<Deal> localDeals = new ArrayList<Deal>();
        if (StringUtils.isBlank(zipCode)) {
            return localDeals;
        }
        localDeals = dealRepository.findByZipCode(zipCode);
        Collections.sort(localDeals, dealComparator);
        return localDeals;
    }

    @RequestMapping(value = "/dealsByZipcode", method = {RequestMethod.GET})
    @ResponseBody
    public List<Deal> dealsByZipcode(@RequestParam String zipCode) throws Exception {
        return getDealsByZipCode(zipCode);
    }

    @RequestMapping(value = "/bookmarkDeal", method = {RequestMethod.POST})
    @ResponseBody
    public UserSavedDeal bookmarkDeal(@RequestParam String userEmail, @RequestParam String dealId) throws Exception {
        if (StringUtils.isBlank(dealId)) {
            throw new BadRequestException("Deal Id is not specified..");
        }
        Deal deal = dealRepository.findById(dealId).orElse(null);
        if (null == deal) {
            throw new NotFoundException("Coupon with " + dealId + " is not found!!");
        }
        User user = userRepository.findByUserEmail(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        UserSavedDeal userSavedDeal = new UserSavedDeal();
        userSavedDeal.setDealId(deal.getId());
        userSavedDeal.setUserId(user.getId());
        userSavedDealRepository.save(userSavedDeal);
        return userSavedDeal;
    }

    @RequestMapping(value = "/deleteFromBookmark", method = {RequestMethod.DELETE})
    @ResponseBody
    public ResponseEntity<String> deleteFromBookmark(@RequestParam String userEmail, @RequestParam String dealId)
            throws Exception {
        if (StringUtils.isBlank(dealId)) {
            throw new BadRequestException("Deal Id is not specified..");
        }
        User user = userRepository.findByUserEmail(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        UserSavedDeal userSavedDeal = userSavedDealRepository.findByUserIdAndDealId(user.getId(), dealId);
        if (null == userSavedDeal) {
            throw new NotFoundException("Bookmark not found with " + dealId);
        }
        userSavedDealRepository.deleteById(userSavedDeal.getId());
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @RequestMapping(value = "/savedDeals", method = {RequestMethod.GET})
    public @ResponseBody
    List<Deal> savedDeals(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        List<Deal> savedDeals = userSavedDealRepository.findByUserId(user.getId());
        Collections.sort(savedDeals, dealComparator);
        return savedDeals;
    }
    
    @Operation(summary = "Get list of online only deals.")
    @RequestMapping(value = "/onlineOnlyDeals", method = {RequestMethod.GET})
    @ResponseBody
    public List<Deal> onlineOnlyDeals() {
    	List<Deal> deals = Optional.ofNullable(dealRepository.findByOnlineOnlyIgnoreCase("Yes"))
    			.orElse(new ArrayList<>());
    	return deals;
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({NotFoundException.class})
    ResponseEntity<String> handleNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
