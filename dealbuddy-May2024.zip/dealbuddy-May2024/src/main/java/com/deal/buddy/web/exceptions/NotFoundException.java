package com.deal.buddy.web.exceptions;

public class NotFoundException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String message;

    public NotFoundException(String message) {
	this.message = message;
    }

    /**
     * @return the message
     */
    public String getMessage() {
	return message;
    }

}
