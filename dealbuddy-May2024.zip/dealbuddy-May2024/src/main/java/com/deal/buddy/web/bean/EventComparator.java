package com.deal.buddy.web.bean;

import java.util.Comparator;

public class EventComparator implements Comparator<Event> {

	public int compare(Event event1, Event event2) {
		if (event1.getEntryTime() > event2.getEntryTime()) {
			return -1;
		} else if (event1.getEntryTime() < event2.getEntryTime()) {
			return 1;
		} else {
			return 0;
		}
	}

}
