package com.deal.buddy.web.bean;

import org.hibernate.annotations.GenericGenerator;

import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.media.Schema.AccessMode;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@Table(name = "db_cards")
public class Card {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	@Schema(accessMode = AccessMode.READ_ONLY, description = "Card id", example = "9814d21c-aa4f-4da8-bced-4d8176e80d31")
	String id;

	@Schema(description = "Card's company name", example = "AMERICAN_EXPRESS")
	@Enumerated(EnumType.STRING)
	@Column(name = "card_company")
	CardCompany cardCompany;

	@Schema(description = "Card type", example = "CREDIT")
	@Enumerated(EnumType.STRING)
	@Column(name = "card_type")
	CardType cardType;

	@Schema(description = "Card name", example = "Gold Card")
	String cardName;

	@Schema(description = "Card summary", example = "American Express Gold Card")
	String cardSummary;

	@Schema(description = "New card member offer", example = "Welcome Gift of 4,000 Bonus Membership Rewards Points")
	String newCardMemberOffer;

	@Schema(description = "Card benefits", example = "Redeem your Points from the fabulous 18 and 24 Karat Gold Collection")
	String cardBenefits;

	@Schema(description = "Card offers and cashback", example = "Earn 5X Membership Reward points on every purchase through Reward Multiplier")
	String offersAndCashback;

	@Schema(description = "Card benefit page link", example = "https://www.americanexpress.com/us/credit-cards/card/gold-card")
	String benefitPageLink;

}
