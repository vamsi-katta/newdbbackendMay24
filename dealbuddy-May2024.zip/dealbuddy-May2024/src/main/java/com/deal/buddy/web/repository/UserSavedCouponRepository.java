package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Coupon;
import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.UserSavedCoupon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Set;

public interface UserSavedCouponRepository extends JpaRepository<UserSavedCoupon, String> {

    @Query("select s from UserSavedCoupon s where s.userId = :userId and s.couponId = :couponId")
    UserSavedCoupon findByUserIdAndCouponId(@Param("userId") String userId, @Param("couponId") String couponId);

    @Query("select c from UserSavedCoupon s, Coupon c where s.userId = :userId and c.id=s.couponId")
    List<Coupon> findByUserId(@Param("userId") String userId);
}
