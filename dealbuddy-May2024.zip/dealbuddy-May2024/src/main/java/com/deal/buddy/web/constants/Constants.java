package com.deal.buddy.web.constants;

public interface Constants {

    String ID = "id";
    String TIMESTAMP = "timeStamp";
    String TITLE = "title";
    String URL = "url";
    String PRICE = "price";
    String RATING = "rating";
    String NOTES = "notes";
    String USER = "user";
    String BRANDS_ARRAY = "brands";
    String VENDORS_ARRAY = "vendors";
    String USERNAME = "userName";
    String BRAND = "brand";
    String CATEGORIES = "categories";
    String KEYWORDS = "keywords";
    String VENDOR = "vendor";
    String INDEX_DEALS = "deals";
    String INDEX_COUPONS = "coupons";
    String INDEX_USERS_VERIFY = "usersverify";
    String INDEX_USERS_SAVED_DEALS = "usersbookmarkdeals";
    String INDEX_USERS_SAVED_COUPONS = "usersbookmarkcoupons";
    String INDEX_USERS = "users";
    String INDEX_DEVICES = "devices";
    String INDEX_SUBSCRIPTION = "subscriptions";
    String INDEX_EVENTS = "events";
    String INDEX_USERS_SAVED_EVENTS = "usersbookmarkevents";
}
