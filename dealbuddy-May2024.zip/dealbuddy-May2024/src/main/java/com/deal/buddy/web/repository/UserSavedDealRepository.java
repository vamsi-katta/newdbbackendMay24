package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Coupon;
import com.deal.buddy.web.bean.Deal;
import com.deal.buddy.web.bean.UserSavedCoupon;
import com.deal.buddy.web.bean.UserSavedDeal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface UserSavedDealRepository extends JpaRepository<UserSavedDeal, String> {

    @Query("select s from UserSavedDeal s where s.userId = :userId and s.dealId = :dealId")
    UserSavedDeal findByUserIdAndDealId(@Param("userId") String userId, @Param("dealId") String dealId);

    @Query("select d from UserSavedDeal s, Deal d where s.userId = :userId and d.id=s.dealId")
    List<Deal> findByUserId(@Param("userId") String userId);
}
