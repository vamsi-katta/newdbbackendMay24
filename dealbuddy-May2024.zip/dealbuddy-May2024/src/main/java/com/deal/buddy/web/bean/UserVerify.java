package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "db_user_verify")
public class UserVerify {
    @Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    String id;
    String userEmail;
    String verifyCode;

    @Override
    public String toString() {
        return "UserVerify [id=" + id + "userEmail=" + userEmail + ", verifyCode=" + verifyCode + "]";
    }

}