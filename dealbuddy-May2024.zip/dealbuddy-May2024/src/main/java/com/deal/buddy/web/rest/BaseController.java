package com.deal.buddy.web.rest;

import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.exceptions.BadRequestException;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.SubscriptionsRepository;
import com.deal.buddy.web.repository.UserRepository;
import com.deal.buddy.web.utils.FileStorageUtils;
import com.deal.buddy.web.utils.S3Utils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.maps.GeoApiContext;
import com.google.maps.GeocodingApi;
import com.google.maps.model.AddressComponent;
import com.google.maps.model.AddressComponentType;
import com.google.maps.model.GeocodingResult;
import com.google.maps.model.LatLng;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;
import java.util.UUID;

public class BaseController {
    private Logger logger = LoggerFactory.getLogger(BaseController.class);
    public static int ES_PAGE_SIZE = NumberUtils.toInt(System.getenv("ES_PAGE_SIZE"), 10);
    private static final GeoApiContext context = new GeoApiContext.Builder().apiKey(System.getenv("GOOGLE_API_KEY"))
            .build();

    @Autowired
    UserRepository userRepository;
    @Autowired
    SubscriptionsRepository subscriptionsRepository;

    public static String s3BasePath = System.getenv("S3_BASE_URL_PATH");

    @Autowired
    FileStorageUtils fileStorageUtils;

    @Autowired
    S3Utils s3Utils;

    public String getS3FullPath(String fileName) {
        StringBuffer sb = new StringBuffer(s3BasePath);
        if (!s3BasePath.endsWith(File.separator)) {
            sb.append(File.separator);
        }
        sb.append(fileName);
        return sb.toString();
    }

    public String getS3FileName(String filePath) {
        if (StringUtils.isBlank(filePath) || !filePath.contains(s3BasePath)) {
            return null;
        }
        String[] fileParts = filePath.split(File.separator);
        return fileParts[fileParts.length - 1];
    }

    public String getS3ImageUrl(String type, String base64ImageString) {
        String fileName = type + UUID.randomUUID().toString() + ".jpg";
        Path filePath = fileStorageUtils.storeFile(base64ImageString, fileName);
        s3Utils.sendFileToS3(filePath, fileName);
        String s3FullPath = getS3FullPath(fileName);
        return s3FullPath;
    }

    public Set<Subscription> getAllPreferences(String userEmail) throws UserNotFoundException {
        User user = userRepository.findByUserEmail(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        Set<Subscription> mySubscriptions = subscriptionsRepository.findByUserId(user.getId());
        return mySubscriptions;
    }

    public User checkUser(String userEmail) {
        return userRepository.findByUserEmail(userEmail);
    }

    public void isPreviliged(String userEmail)
            throws UserNotFoundException, BadRequestException, JsonParseException, JsonMappingException, IOException {
        User userFetched = userRepository.findByUserEmail(userEmail);
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }

        boolean isPreviliged = false;
        if ("dealer".equalsIgnoreCase(userFetched.getRole())) {
            isPreviliged = true;
        }

        if (!isPreviliged) {
            throw new BadRequestException("User does not have permissions!!");
        }
    }

    public String getZipCode(Double latitude, Double longitude) {
        String zipcode = null;
        try {
            LatLng latLng = new LatLng(latitude, longitude);
            GeocodingResult[] results = GeocodingApi.reverseGeocode(context, latLng).await();
            if (null != results) {
                for (GeocodingResult geocodingResult : results) {
                    AddressComponent[] addressComponents = geocodingResult.addressComponents;
                    if (null != addressComponents) {
                        for (AddressComponent addressComponent : addressComponents) {
                            AddressComponentType[] types = addressComponent.types;
                            if (null != types) {
                                for (AddressComponentType addressComponentType : types) {
                                    if (AddressComponentType.POSTAL_CODE == addressComponentType) {
                                        zipcode = addressComponent.longName;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            logger.debug("zipcode : " + zipcode);
        } catch (Exception e) {
            logger.debug(e.toString());
            logger.debug(e.getLocalizedMessage());
        }
        return zipcode;
    }
}
