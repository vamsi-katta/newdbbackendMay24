package com.deal.buddy.web.exceptions;

public class UserNotFoundException extends Exception {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String message;

    public UserNotFoundException(String message) {
	this.message = message;
    }

    /**
     * @return the message
     */
    public String getMessage() {
	return message;
    }

}
