package com.deal.buddy.web.utils;

import com.deal.buddy.web.bean.*;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    private static ObjectMapper mapper = new ObjectMapper();

    public static String getJson(User user) throws JsonProcessingException {
        return mapper.writeValueAsString(user);
    }

    public static User getUser(String userJson) throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(userJson, User.class);
    }

    public static String getJson(Deal d) throws JsonProcessingException {
        return mapper.writeValueAsString(d);
    }

    public static Deal getDeal(String dealJson) throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(dealJson, Deal.class);
    }

    public static String getJson(Coupon d) throws JsonProcessingException {
        return mapper.writeValueAsString(d);
    }

    public static Coupon getCoupon(String couponJson) throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(couponJson, Coupon.class);
    }

    public static String getJson(UserSavedDeal usd) throws JsonProcessingException {
        return mapper.writeValueAsString(usd);
    }

    public static UserSavedDeal getUserSavedDeal(String usdJson)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(usdJson, UserSavedDeal.class);
    }

    public static String getJson(UserSavedEvent usd) throws JsonProcessingException {
        return mapper.writeValueAsString(usd);
    }

    public static UserSavedEvent getUserSavedEvent(String usdJson)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(usdJson, UserSavedEvent.class);
    }

    public static String getJson(UserSavedCoupon usc) throws JsonProcessingException {
        return mapper.writeValueAsString(usc);
    }

    public static UserSavedCoupon getUserSavedCoupon(String uscJson)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(uscJson, UserSavedCoupon.class);
    }

    public static String getJson(UserVerify d) throws JsonProcessingException {
        return mapper.writeValueAsString(d);
    }

    public static UserVerify getUserVerify(String userVerifyString)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(userVerifyString, UserVerify.class);
    }

    public static String getJson(UserDevice d) throws JsonProcessingException {
        return mapper.writeValueAsString(d);
    }

    public static UserDevice getUserDevice(String userDeviceJson)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(userDeviceJson, UserDevice.class);
    }

    public static String getJson(Subscription s) throws JsonProcessingException {
        return mapper.writeValueAsString(s);
    }

    public static Subscription getSubscription(String json)
            throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(json, Subscription.class);
    }

    public static String getJson(Event event) throws JsonProcessingException {
        return mapper.writeValueAsString(event);
    }

    public static Event getEvent(String eventJson) throws JsonParseException, JsonMappingException, IOException {
        return mapper.readValue(eventJson, Event.class);
    }

}
