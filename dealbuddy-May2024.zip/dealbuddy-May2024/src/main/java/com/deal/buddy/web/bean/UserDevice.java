package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;

@Entity
@Getter
@Setter
@Table(name = "db_user_devices")
public class UserDevice {
	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid2")
	String deviceId;
	String os;
	String userEmail;

	@Override
	public String toString() {
		return "UserDevice [deviceId=" + deviceId + ", os=" + os + ", userEmail=" + userEmail + "]";
	}

}