package com.deal.buddy.web.repository;

import com.deal.buddy.web.bean.Coupon;
import com.deal.buddy.web.bean.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends JpaRepository<User, String> {

    User findByUserEmail(String userEmail);
}
