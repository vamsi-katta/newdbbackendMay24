package com.deal.buddy.web.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Card;
import com.deal.buddy.web.exceptions.NotFoundException;
import com.deal.buddy.web.repository.CardRepository;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;

@RestController
@RequestMapping("/dealbuddy/rest/cards")
public class CardController extends BaseController {

	private Logger logger = LoggerFactory.getLogger(CardController.class);

	@Autowired
	CardRepository cardRepository;

	@Operation(summary = "Add new card")
	@RequestMapping(method = {RequestMethod.POST})
	public @ResponseBody
	Card addCard(@RequestBody Card card) {
		Card newCard = cardRepository.save(card);
		logger.info("Card added : {}", newCard);
		return newCard;
	}

	@Operation(summary = "Get all cards")
	@RequestMapping(method = {RequestMethod.GET})
	public @ResponseBody
	List<Card> getAllCards() {
		return cardRepository.findAll();
	}

	@Operation(summary = "Delete a card")
	@RequestMapping(method = {RequestMethod.DELETE})
	public ResponseEntity<String> deleteCard(
			@Parameter(description = "Card id", required = true, example = "9814d21c-aa4f-4da8-bced-4d8176e80d31") @RequestParam String id)
					throws Exception {
		Card card = cardRepository.findById(id)
				.orElseThrow(() -> new NotFoundException("Card with " + id + " is not found!!"));
		cardRepository.delete(card);
		return new ResponseEntity<String>("Card deleted successfully!", HttpStatus.OK);
	}

	@Operation(summary = "Get card details by id")
	@RequestMapping(value = "/card", method = {RequestMethod.GET})
	public @ResponseBody
	Card getCardById(
			@Parameter(description = "Card id", required = true, example = "9814d21c-aa4f-4da8-bced-4d8176e80d31") @RequestParam String id) 
					throws Exception {
		Card card = cardRepository.findById(id)
				.orElseThrow(() -> new NotFoundException("Card with " + id + " is not found!!"));
		return card;
	}

}
