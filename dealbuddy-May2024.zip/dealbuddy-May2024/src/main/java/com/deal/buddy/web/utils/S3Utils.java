package com.deal.buddy.web.utils;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


import java.nio.file.Path;

@Component
@Slf4j
public class S3Utils {

    private TransferManager transferManager;
    private String bucketName = System.getenv("S3_BUCKET_NAME");
    private String region = System.getenv("S3_REGION");;
    private Regions S3_REGION;
    private String awsKey = System.getenv("AWS_KEY");;
    private String awsSecret = System.getenv("AWS_SECRET");;

//    @PostConstruct
    public void init() {
        S3_REGION = Regions.fromName(region);
        log.info("Initializing S3 utils.");
        AWSCredentials awsCredentials = new BasicAWSCredentials(awsKey, awsSecret);
        AWSStaticCredentialsProvider chain = new AWSStaticCredentialsProvider(awsCredentials);
        AmazonS3 amazonS3 = AmazonS3ClientBuilder.standard().withCredentials(chain).withRegion(S3_REGION.getName())
                .build();
        transferManager = TransferManagerBuilder.standard().withS3Client(amazonS3).build();

        log.info("Initialized S3 utils, bucket Name : {}", bucketName);
    }

    /**
     *
     * @param filePath
     *            to send S3
     * @param key
     *            of the object/file
     * @return true if the file sent successfully else false.
     */
    public boolean sendFileToS3(Path filePath, String key) {
        try {
            if (transferManager != null) {
                PutObjectRequest pr = new PutObjectRequest(bucketName, key, filePath.toFile())
                        .withCannedAcl(CannedAccessControlList.PublicRead);

                Upload upload = transferManager.upload(pr);
                try {
                    upload.waitForCompletion();
                } catch (InterruptedException e) {
                    log.error("Exception while sending file to S3.", e);
                    return false;
                }
                return true;
            }
            log.error("Transfer manager is null!!!!!!!!!!!!!!!");
        } catch (Exception e) {
            log.error("Exception while uploading the image {} to s3", key, e);
        }
        return false;
    }

    /**
     * Deletes the key of the object.
     *
     * @param key
     * @return
     */
    public boolean deleteKey(String key) {
        try {
            if (transferManager != null) {
                DeleteObjectRequest dr = new DeleteObjectRequest(bucketName, key);
                transferManager.getAmazonS3Client().deleteObject(dr);
                return true;
            }
            log.error("Transfer manager is null!!!!!!!!!!!!!!!");
        } catch (Exception e) {
            log.error("Exception while deleting the image {} from s3", key, e);
        }
        return false;
    }

}
