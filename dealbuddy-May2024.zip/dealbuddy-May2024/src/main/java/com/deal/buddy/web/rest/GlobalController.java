package com.deal.buddy.web.rest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Coupon;
import com.deal.buddy.web.bean.CouponComparator;
import com.deal.buddy.web.bean.Deal;
import com.deal.buddy.web.bean.DealComparator;
import com.deal.buddy.web.bean.Event;
import com.deal.buddy.web.bean.EventComparator;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.CouponRepository;
import com.deal.buddy.web.repository.DealRepository;
import com.deal.buddy.web.repository.EventRepository;
import com.deal.buddy.web.repository.UserSavedCouponRepository;
import com.deal.buddy.web.repository.UserSavedDealRepository;
import com.deal.buddy.web.repository.UserSavedEventRepository;
import com.deal.buddy.web.utils.JsonUtils;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/global")
public class GlobalController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(GlobalController.class);
    private static DealComparator dealComparator = new DealComparator();
    private static CouponComparator couponComparator = new CouponComparator();
    private static EventComparator eventComparator = new EventComparator();


    @Autowired
    UserSavedDealRepository userSavedDealRepository;

    @Autowired
    UserSavedCouponRepository userSavedCouponRepository;

    @Autowired
    UserSavedEventRepository userSavedEventRepository;

    @Autowired
    DealRepository dealRepository;

    @Autowired
    CouponRepository couponRepository;

    @Autowired
    EventRepository eventRepository;


    @RequestMapping(value = "/allSaved", method = {RequestMethod.GET})
    public @ResponseBody
    List<String> getAllSavedItems(@RequestParam String userEmail) throws UserNotFoundException {
        User user = checkUser(userEmail);
        if (null == user) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        List<String> results = new ArrayList<String>();
        try {
            List<Deal> savedDeals =  userSavedDealRepository.findByUserId(user.getId());
            Collections.sort(savedDeals, dealComparator);
            for (Deal deal : savedDeals) {
                results.add(JsonUtils.getJson(deal));
            }
            List<Coupon> savedCoupons = userSavedCouponRepository.findByUserId(user.getId());
            Collections.sort(savedCoupons, couponComparator);
            for (Coupon coupon : savedCoupons) {
                results.add(JsonUtils.getJson(coupon));
            }
            List<Event> savedEvents = userSavedEventRepository.findByUserId(user.getId());
            Collections.sort(savedEvents, eventComparator);
            for (Event event : savedEvents) {
                results.add(JsonUtils.getJson(event));
            }
        } catch (Exception e) {
            logger.error("Exception while getting myAllSaved results.", e);
        }
        return results;
    }

    @RequestMapping(value = "/search", method = {RequestMethod.GET})
    public @ResponseBody
    List<String> getSearchItems(@RequestParam String toBeSearched) {
        List<String> results = new ArrayList<String>();
        try {
            String[] searchTerms = toBeSearched.split(",");
            List<Deal> dealsBySearchTerms = dealRepository.findBySearchTerms(searchTerms);
            if (CollectionUtils.isNotEmpty(dealsBySearchTerms)) {
                Collections.sort(dealsBySearchTerms, dealComparator);
                for (Deal deal : dealsBySearchTerms) {
                    results.add(JsonUtils.getJson(deal));
                }
            }
            List<Coupon> couponsBySearchTerms = couponRepository.findBySearchTerms(searchTerms);
            if (CollectionUtils.isNotEmpty(couponsBySearchTerms)) {
                Collections.sort(couponsBySearchTerms, couponComparator);
                for (Coupon coupon : couponsBySearchTerms) {
                    results.add(JsonUtils.getJson(coupon));
                }
            }
        } catch (Exception e) {
            logger.error("Exception while getting search results.", e);
        }
        return results;
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
