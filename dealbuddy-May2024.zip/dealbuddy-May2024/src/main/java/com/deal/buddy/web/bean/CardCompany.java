package com.deal.buddy.web.bean;

public enum CardCompany {
	AMERICAN_EXPRESS
}
