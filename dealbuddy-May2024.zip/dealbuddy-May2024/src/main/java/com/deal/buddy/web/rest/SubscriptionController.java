package com.deal.buddy.web.rest;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.deal.buddy.web.bean.Subscription;
import com.deal.buddy.web.bean.User;
import com.deal.buddy.web.exceptions.UserNotFoundException;
import com.deal.buddy.web.repository.SubscriptionsRepository;

/**
 * @author Venu Nerella
 */
@RestController
@RequestMapping("/dealbuddy/rest/subscriptions")
public class SubscriptionController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(SubscriptionController.class);

    @Autowired
    SubscriptionsRepository subscriptionsRepository;


    @RequestMapping(method = {RequestMethod.POST})
    public @ResponseBody
    Subscription addPreference(@RequestBody Subscription subScription,
                               @RequestParam String userEmail) throws Exception {
        logger.info("Preference added : {}", subScription);
        User userFetched = checkUser(userEmail);
        if (null == userFetched) {
            throw new UserNotFoundException("User with " + userEmail + " is not found!!");
        }
        subScription.setUserId(userFetched.getId());
        subscriptionsRepository.save(subScription);
        return subScription;
    }

    @RequestMapping(method = {RequestMethod.GET})
    public @ResponseBody
    Set<Subscription> myPreferences(@RequestParam String userEmail) throws UserNotFoundException {
        return getAllPreferences(userEmail);
    }

    @RequestMapping(method = {RequestMethod.DELETE})
    public ResponseEntity<String> deleteSubscription(@RequestParam String userEmail,
                                                     @RequestParam String subscriptionId) throws Exception {
        subscriptionsRepository.deleteById(subscriptionId);
        HttpStatus httpStatus = HttpStatus.OK;
        return new ResponseEntity<String>(httpStatus.name(), httpStatus);
    }

    @ExceptionHandler({UserNotFoundException.class})
    ResponseEntity<String> handleUserNotFoundException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler({Exception.class})
    ResponseEntity<String> handleBadReqException(Exception e) {
        return new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

}
