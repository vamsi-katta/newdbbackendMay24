package com.deal.buddy.web.bean;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "db_users")
public class User  implements Serializable {
	@Id
    @GeneratedValue(generator = "system-uuid")
    @GenericGenerator(name = "system-uuid", strategy = "uuid2")
    @Column(name = "user_id")
	String id;
	String infoProvider;
	String userEmail;
	String firstName;
	String role;
	boolean pnsEnabled;
	boolean emailEnabled;
	String gender;
	String zipCode;

	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}

}